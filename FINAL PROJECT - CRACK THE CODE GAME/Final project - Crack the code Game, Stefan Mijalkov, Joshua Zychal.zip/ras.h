/*
 * ras.h
 *
 *  Created on: Mar 5, 2019
 *      Author: Stefan Mijalkov
 */

#ifndef RAS_H_
#define RAS_H_

void rasInit();

void rasRead(uint32_t data[]);

#endif /* RAS_H_ */
